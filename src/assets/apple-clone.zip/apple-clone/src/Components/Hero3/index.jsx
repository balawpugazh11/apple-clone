import React from 'react';
import heroBg from "../../assets/hero_3_max.jpg";

function Hero3() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center text-center px-4">
      {/* Background Image */}
      <div
        className="absolute inset-0 z-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroBg})` }}
      ></div>

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-100/50 via-transparent to-white/50"></div>

      {/* Content */}
      <div className="relative flex flex-col items-center justify-center max-w-2xl space-y-6 text-center p-6 z-10">
        <h1 className="text-4xl md:text-6xl font-semibold text-gray-900">MacBook Air</h1>
        <p className="text-lg md:text-xl text-gray-800">Sky blue colour.</p>
        <p className="text-lg md:text-xl text-gray-800">Sky high performance with M4.</p>
        
        {/* Price */}
        <p className="text-lg md:text-xl text-gray-700">
          From ₹114900.00
        </p>
        
        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 pt-4">
          <button className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-8 rounded-full text-lg transition-all duration-200 transform hover:scale-105">
            Buy
          </button>
          <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-50 font-medium py-3 px-8 rounded-full text-lg transition-all duration-200 transform hover:scale-105">
            Learn more
          </button>
        </div>
      </div>
      
      {/* Bottom Gradient Text */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-center">
        <p className="text-lg font-medium text-gray-900">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500">
            Built for Apple Intelligence.
          </span>
        </p>
      </div>
    </section>
  );
}

export default Hero3;
