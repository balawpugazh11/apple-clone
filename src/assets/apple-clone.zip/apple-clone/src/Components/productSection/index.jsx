import React from "react";

function ProductSection({ image, title, lines, textColor, descColor, bgColor }) {
  return (
    <section className={`w-full min-h-screen flex flex-col items-center justify-start text-center py-16 px-4 ${bgColor} relative overflow-hidden group`}>
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-32 h-32 bg-gradient-to-br from-blue-400 to-purple-400 rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 right-10 w-24 h-24 bg-gradient-to-br from-pink-400 to-orange-400 rounded-full blur-2xl"></div>
      </div>
      
      <div className="max-w-xl space-y-4 mt-12 relative z-10">
        <h1 className={`text-4xl md:text-6xl font-semibold ${textColor} transition-all duration-300 group-hover:scale-105`}>
          {title}
        </h1>
        {lines.map((line, i) => (
          <p key={i} className={`text-lg md:text-xl ${descColor} transition-all duration-300 delay-${i * 100}`}>
            {line}
          </p>
        ))}

        <div className="flex flex-wrap justify-center gap-6 pt-6">
          <button className="text-blue-600 hover:text-blue-700 font-medium text-sm transition-all duration-200 hover:underline flex items-center gap-1 group">
            Learn more 
            <span className="transition-transform duration-200 group-hover:translate-x-1">›</span>
          </button>
          <button className="text-blue-600 hover:text-blue-700 font-medium text-sm transition-all duration-200 hover:underline flex items-center gap-1 group">
            Buy 
            <span className="transition-transform duration-200 group-hover:translate-x-1">›</span>
          </button>
        </div>
      </div>

      <div className="relative z-10 mt-10 transition-all duration-500 group-hover:scale-105">
        <img
          src={image}
          alt={title}
          className="max-w-[650px] w-full h-auto object-contain drop-shadow-2xl"
        />
      </div>

      <p className={`text-base mt-8 ${textColor} relative z-10`}>
        Built for{" "}
        <span className="font-semibold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500">
          Apple Intelligence
        </span>
      </p>
    </section>
  );
}

export default ProductSection;
