import React from "react";

const Footer = () => {
  return (
    <footer className="bg-[#f5f5f7] text-[#6e6e73] text-sm">
      <div className="max-w-7xl mx-auto px-4 py-10">
        {/* Disclaimer */}
        <p className="mb-4 border-b border-gray-300 pb-4 text-xs">
          * Listed pricing is for illustrative purposes only. Final pricing may vary.
        </p>

        {/* Link Sections */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6 mb-8">
          <div>
            <h3 className="text-black font-semibold mb-3">Shop and Learn</h3>
            <ul className="space-y-2">
              {["Store", "Mac", "iPad", "iPhone", "Watch", "AirPods", "TV & Home", "Accessories", "Gift Cards"].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-black transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-black font-semibold mb-3">Services</h3>
            <ul className="space-y-2">
              {["Apple Music", "Apple TV+", "Apple Arcade", "iCloud", "Apple One", "Apple Books", "Apple Podcasts", "App Store"].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-black transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-black font-semibold mb-3">Apple Store</h3>
            <ul className="space-y-2">
              {["Find a Store", "Genius Bar", "Today at Apple", "Apple Camp", "Ways to Buy", "Recycling", "Order Status", "Shopping Help"].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-black transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-black font-semibold mb-3">For Business</h3>
            <ul className="space-y-2 mb-4">
              {["Apple and Business", "Shop for Business"].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-black transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
            <h3 className="text-black font-semibold mb-3">For Education</h3>
            <ul className="space-y-2">
              {["Apple and Education", "Shop for Education", "Shop for University"].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-black transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-black font-semibold mb-3">Apple Values</h3>
            <ul className="space-y-2 mb-4">
              {["Accessibility", "Environment", "Privacy", "Supplier Responsibility"].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-black transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
            <h3 className="text-black font-semibold mb-3">About Apple</h3>
            <ul className="space-y-2">
              {["Newsroom", "Apple Leadership", "Career Opportunities", "Investors", "Ethics & Compliance", "Events", "Contact Apple"].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-black transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-300 pt-4 text-xs text-[#6e6e73] flex flex-col md:flex-row justify-between items-start md:items-center">
          {/* Location */}
          <p className="mb-2 md:mb-0">India</p>

          {/* Legal Links */}
          <div className="flex flex-wrap gap-4">
            {["Privacy Policy", "Terms of Use", "Sales Policy", "Legal", "Site Map"].map((item) => (
              <a key={item} href="#" className="hover:text-black transition-colors duration-200">
                {item}
              </a>
            ))}
          </div>
        </div>

        {/* Copyright */}
        <p className="mt-4 text-xs">&copy; 2025 Apple Inc. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
