import React from 'react'

function PromoBanner() {
  return (
    <div className="text-center text-sm py-3 bg-white shadow-sm border-b border-gray-100">
      <p className="text-gray-600">
        Get up to <strong className="text-gray-900">12 months</strong> of <strong className="text-gray-900">No Cost EMI</strong>{" "}
        plus up to <strong className="text-gray-900">₹8000.00</strong> instant cashback‡ on selected products with eligible cards.{" "}
        <a href="#" className="text-blue-600 hover:text-blue-700 hover:underline transition-colors duration-200 font-medium">
          Shop ›
        </a>
      </p>
    </div>
  )
}

export default PromoBanner;