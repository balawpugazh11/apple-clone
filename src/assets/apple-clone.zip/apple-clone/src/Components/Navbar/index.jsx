import React, { useState, useEffect } from "react";
import { FaApple, FaStore, FaSearch, FaBars, FaTimes } from "react-icons/fa";

const AppleNavbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    "Store",
    "Mac",
    "iPad",
    "iPhone",
    "Watch",
    "AirPods",
    "TV & Home",
    "Entertainment",
    "Accessories",
    "Support",
  ];

  return (
    <div className="font-sans text-gray-800">
      <nav className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/80 backdrop-blur-md shadow-sm' 
          : 'bg-white/30 backdrop-blur-sm'
      } w-full`}>
        <div className="max-w-screen-xl mx-auto px-4 flex items-center justify-between py-3">
          {/* Left: Apple Logo */}
          <a href="#" className="hover:text-black transition-colors duration-200">
            <FaApple className="h-5 w-5" />
          </a>

          {/* Center: Desktop Nav */}
          <div className="hidden lg:flex space-x-8 text-sm">
            {navItems.map((item) => (
              <a
                key={item}
                href="#"
                className="hover:text-black transition-colors duration-200 flex items-center gap-1 relative group"
              >
                {item === "Store" && <FaStore className="inline-block" />}
                {item}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-black transition-all duration-200 group-hover:w-full"></span>
              </a>
            ))}
          </div>

          {/* Right: Search + Mobile Menu Button */}
          <div className="flex items-center space-x-4">
            <a href="#" className="hover:text-black transition-colors duration-200 p-1">
              <FaSearch className="w-4 h-4" />
            </a>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="lg:hidden focus:outline-none p-1 transition-colors duration-200"
              aria-label="Toggle menu"
            >
              {isOpen ? (
                <FaTimes className="w-5 h-5" />
              ) : (
                <FaBars className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="lg:hidden bg-white/95 backdrop-blur-md border-t border-gray-200 px-4 pb-4 space-y-2 text-sm animate-in slide-in-from-top-2 duration-200">
            {navItems.map((item) => (
              <a
                key={item}
                href="#"
                className="block hover:text-black transition-colors duration-200 border-b border-gray-100 py-3"
                onClick={() => setIsOpen(false)}
              >
                {item === "Store" && (
                  <span className="inline-block mr-1">
                    <FaStore className="inline-block" />
                  </span>
                )}
                {item}
              </a>
            ))}
          </div>
        )}
      </nav>
    </div>
  );
};

export default AppleNavbar;
