import React from 'react'
import Movie_poster from '../../assets/Movie_poster_2.jpg'  

function MoviePoster() {
  return (
    <section className="relative overflow-hidden group">
      <div className="relative">
        <img 
          src={Movie_poster} 
          alt="Apple TV+ Original" 
          className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-105" 
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
        
        {/* Content */}
        <div className="absolute bottom-8 left-8 text-white">
          <h2 className="text-2xl md:text-3xl font-semibold mb-2">Apple TV+</h2>
          <p className="text-lg md:text-xl mb-4">Stream the latest Apple Originals</p>
          <button className="bg-white text-black font-medium py-2 px-6 rounded-full text-sm hover:bg-gray-100 transition-colors duration-200">
            Stream now
          </button>
        </div>
      </div>
    </section>
  )
}

export default MoviePoster;