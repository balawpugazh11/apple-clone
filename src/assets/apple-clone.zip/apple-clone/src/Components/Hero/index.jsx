import React from "react";
import heroBg from "../../assets/hero_1_max.jpg";

const Hero = () => {
  return (
    <section
      className="relative flex items-center justify-center min-h-screen bg-cover bg-center overflow-hidden"
      style={{ backgroundImage: `url(${heroBg})` }}
    >
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/10"></div>
      
      <div className="text-center space-y-6 z-10 flex flex-col items-center justify-center p-6 relative">
        {/* Main Title */}
        <h1 className="text-5xl md:text-7xl font-semibold text-white leading-tight">
          iPhone 16 Pro
        </h1>
        
        {/* Subtitle */}
        <p className="text-xl md:text-2xl text-white/90 font-medium">
          Titanium. So strong. So light. So Pro.
        </p>
        
        {/* Price */}
        <p className="text-lg md:text-xl text-white/80">
          From ₹149900.00
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 pt-4">
          <button className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-8 rounded-full text-lg transition-all duration-200 transform hover:scale-105">
            Buy
          </button>
          <button className="border-2 border-white text-white hover:bg-white hover:text-black font-medium py-3 px-8 rounded-full text-lg transition-all duration-200 transform hover:scale-105">
            Learn more
          </button>
        </div>
      </div>
      
      {/* Bottom Gradient Text */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-center">
        <p className="text-lg font-medium text-white">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400">
            Built for Apple Intelligence.
          </span>
        </p>
      </div>
    </section>
  );
};

export default Hero;
